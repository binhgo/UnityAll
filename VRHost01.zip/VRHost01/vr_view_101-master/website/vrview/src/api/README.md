This directory contains all of the JavaScript that is required for the
VR View JavaScript API.
